📦 Amazon Policy RAG Assistant (LangGraph Linear RAG)

This project implements a foundational Retrieval-Augmented Generation (RAG) pipeline using LangGraph to create a helpful assistant that answers questions based on a set of provided internal Amazon policy documents.

The core architecture follows a simple, robust linear flow: Retrieve Context $\rightarrow$ Generate Answer.

⚙️ Architecture and Flow

The LangGraph is configured as a simple two-node linear chain using the RAGState to manage data transfer:

Retrieve Node: Takes the user's question, performs a similarity search against the FAISS vector store, and populates the state's context field with the retrieved text.

Generate Node: Takes the question and the gathered context, formats them into a final prompt, and uses the LLM (Azure Chat OpenAI) to generate the final, grounded answer. The system prompt instructs the assistant to act as an Amazon support agent and always cite the retrieved information.

State Management (RAGState)

Key

Type

Description

question

str

The user's original query.

context

Optional[str]

The relevant text retrieved from the vector store.

answer

Optional[str]

The final generated response from the LLM.

🚀 Setup and Installation

Prerequisites

You must have access to Azure OpenAI Services for both the large language model and the embedding model.

API Keys & Endpoints: Gather your credentials for the Azure services.

.env File: Create a file named .env in the project root and configure it with your specific Azure endpoints and model deployment names.

# ---- EMBEDDING CONFIG ----
AZURE_OPENAI_EMBEDDING_API_KEY="YOUR_AZURE_EMBEDDING_API_KEY"
AZURE_OPENAI_EMBEDDING_ENDPOINT="YOUR_AZURE_EMBEDDING_ENDPOINT"
AZURE_OPENAI_EMBED_MODEL="YOUR_AZURE_EMBEDDING_DEPLOYMENT_NAME"

# ---- LLM CONFIG ----
AZURE_OPENAI_LLM_API_KEY="YOUR_AZURE_LLM_API_KEY"
AZURE_OPENAI_LLM_ENDPOINT="YOUR_AZURE_LLM_ENDPOINT"
AZURE_OPENAI_LLM_MODEL="YOUR_AZURE_LLM_DEPLOYMENT_NAME"


Python Dependencies

Install the required libraries:

pip install langchain-openai langchain-community langgraph faiss-cpu langchain-core python-dotenv


💻 Running the Application

Save the provided Python code as a file
Ensure your .env file is configured correctly.

Execute the script:

py main.py


Example Question and Output

The script uses the example question: "Can I return an opened Amazon Kindle?"

Mock RAG Context:

The internal vector store is initialized with these policy documents:

"Amazon customers can return most items within 30 days of receipt for a full refund."

"Digital products purchased from Amazon, such as eBooks or apps, are not eligible for return once downloaded."

"Amazon Prime members receive free two-day shipping on eligible items."

"Electronics purchased from Amazon must be returned in new condition with all original packaging and accessories."

"Amazon Kindle devices may be returned within 30 days of delivery, provided the device is in new condition."

Expected Output (similar to):

Retrieved Context:
 Amazon customers can return most items within 30 days of receipt for a full refund.
 Amazon Kindle devices may be returned within 30 days of delivery, provided the device is in new condition.

Generated Answer:
 Yes, Amazon Kindle devices may be returned within 30 days of delivery, provided the device is in new condition. Most items can be returned within 30 days of receipt for a full refund.


📚 Customization

To expand the knowledge base, simply add more Document objects to the docs list in Step 2. The FAISS vector store will automatically be re-indexed with the new information upon startup.