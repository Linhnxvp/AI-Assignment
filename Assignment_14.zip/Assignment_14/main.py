# Step 0: Imports & Environment Setup
import os
from typing import TypedDict, Optional
from langchain_openai import AzureOpenAIEmbeddings, AzureChatOpenAI
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_core.prompts import ChatPromptTemplate
from langgraph.graph import StateGraph, END
from dotenv import load_dotenv

# --- Load environment variables ---
load_dotenv()

# Step 1: Config LLM
AZURE_OPENAI_EMBEDDING_API_KEY = os.getenv("AZURE_OPENAI_EMBEDDING_API_KEY")
AZURE_OPENAI_EMBEDDING_ENDPOINT = os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT")
AZURE_OPENAI_EMBED_MODEL = os.getenv("AZURE_OPENAI_EMBED_MODEL")

AZURE_OPENAI_LLM_API_KEY = os.getenv("AZURE_OPENAI_LLM_API_KEY")
AZURE_OPENAI_LLM_ENDPOINT = os.getenv("AZURE_OPENAI_LLM_ENDPOINT")
AZURE_OPENAI_LLM_MODEL = os.getenv("AZURE_OPENAI_LLM_MODEL")

# Step 2: Sample Documents
docs = [
    Document(page_content="Amazon customers can return most items within 30 days of receipt for a full refund."),
    Document(page_content="Digital products purchased from Amazon, such as eBooks or apps, are not eligible for return once downloaded."),
    Document(page_content="Amazon Prime members receive free two-day shipping on eligible items."),
    Document(page_content="Electronics purchased from Amazon must be returned in new condition with all original packaging and accessories."),
    Document(page_content="Amazon Kindle devices may be returned within 30 days of delivery, provided the device is in new condition."),
]

# Step 3: Typed State for LangGraph
class RAGState(TypedDict):
    question: str
    context: Optional[str]
    answer: Optional[str]

# Step 4: Embedding & Vector Store
embeddings = AzureOpenAIEmbeddings(
    azure_endpoint=AZURE_OPENAI_EMBEDDING_ENDPOINT,
    api_key=AZURE_OPENAI_EMBEDDING_API_KEY,
    model=AZURE_OPENAI_EMBED_MODEL,
    api_version="2024-07-01-preview",
)
vectorstore = FAISS.from_documents(docs, embeddings)
retriever = vectorstore.as_retriever(search_kwargs={"k": 2})

# Step 5: Azure Chat Model
llm = AzureChatOpenAI(
    azure_endpoint=AZURE_OPENAI_LLM_ENDPOINT,
    api_key=AZURE_OPENAI_LLM_API_KEY,
    deployment_name=AZURE_OPENAI_LLM_MODEL,
    api_version="2024-07-01-preview",
    temperature=0,
)

# Step 6: Prompt Template
prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful Amazon support assistant. Use the provided information to answer product and policy questions. Always cite the retrieved info in your answer."),
    ("human", "{context}\n\nUser question: {question}"),
])

# Step 7: Define Nodes
def retrieve_node(state: RAGState) -> RAGState:
    docs = retriever.invoke(state["question"])
    context = "\n".join(doc.page_content for doc in docs)
    return {**state, "context": context}

def generate_node(state: RAGState) -> RAGState:
    formatted_prompt = prompt.format(context=state["context"], question=state["question"])
    answer = llm.invoke(formatted_prompt)
    return {**state, "answer": answer.content}

# Step 8: Build LangGraph
builder = StateGraph(RAGState)
builder.add_node("retrieve", retrieve_node)
builder.add_node("generate", generate_node)
builder.set_entry_point("retrieve")
builder.add_edge("retrieve", "generate")
builder.set_finish_point("generate")
rag_graph = builder.compile()

# Step 9: Run
if __name__ == "__main__":
    user_question = "Can I return an opened Amazon Kindle?"
    result = rag_graph.invoke({"question": user_question})
    print(" Retrieved Context:\n", result["context"])
    print("\n Generated Answer:\n", result["answer"])