import os
from langchain.tools import tool
from langchain_openai import AzureChatOpenAI
from langchain_community.utilities import OpenWeatherMapAPIWrapper
from langchain_tavily import TavilySearch
from langgraph.prebuilt import create_react_agent
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Define weather tool
weather = OpenWeatherMapAPIWrapper()

@tool
def get_weather(city: str) -> str:
    """
    Get the current weather for a given city.
    Args:
        city (str): The name of the city to get the weather for.
    Returns:
        str: A string describing the current weather in the specified city.
    """
    print(f"Calling weather tool: Getting weather for {city}")
    return weather.run(city)

# Initialize Tavily search tool
tavily_search_tool = TavilySearch(
    max_results=1,
    topic="general",
)


# Initialize Azure OpenAI LLM
llm = AzureChatOpenAI(
    azure_deployment=os.getenv("AZURE_OPENAI_LLM_MODEL"),
    azure_endpoint=os.getenv("AZURE_OPENAI_LLM_ENDPOINT"),
    api_version="2024-07-01-preview",
    api_key=os.getenv("AZURE_OPENAI_LLM_API_KEY"),
)

# Setup LangChain Agent with Tools
tools = [get_weather, tavily_search_tool]
agent = create_react_agent(model=llm, tools=tools)

print("Welcome to the AI assistant. Type 'exit' to stop.\n")

messages = []

# Mock input
questions_file = "questions.txt"
with open(questions_file, "r", encoding="utf-8") as f:
    questions = [line.strip() for line in f if line.strip()]

for user_input in questions:
    print("User:", user_input)
    if user_input.lower() == "exit":
        print("Goodbye!")
        break

    messages.append({"role": "user", "content": user_input})

    response = agent.invoke({"messages": messages})
    messages.append({"role": "assistant", "content": response["messages"][-1].content})

    print("AI:", response["messages"][-1].content)
    print("-" * 50)
    
print("Conversation loop finished.")
