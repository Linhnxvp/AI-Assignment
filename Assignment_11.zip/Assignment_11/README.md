# Tổng Quan Dự Án
Đây là một dự án Trợ lý Tác nhân AI (AI Agent) đa năng, được xây dựng trên nền tảng LangChain và LangGraph. Trợ lý được thiết kế để xử lý và trả lời hai loại truy vấn chính:

Thông tin thời tiết: Sử dụng công cụ bên ngoài để cung cấp dữ liệu thời tiết cập nhật.

Truy vấn tổng quát: Sử dụng công cụ tìm kiếm web để trả lời các câu hỏi về tin tức hoặc thông tin chung.

Nền tảng của hệ thống là mô hình ngôn ngữ lớn (LLM) được cung cấp bởi Azure OpenAI.

# Công Cụ và Yêu Cầu
Yêu Cầu Tiên Quyết (Prerequisites)
Để vận hành hệ thống, bạn cần chuẩn bị các tài khoản và khóa API sau:

Python 3.8+

Azure OpenAI: Khóa API và cấu hình triển khai mô hình (deployment) đã sẵn sàng.

OpenWeatherMap: Khóa API để truy cập dữ liệu thời tiết.

Tavily Search: Khóa API để thực hiện các truy vấn tìm kiếm web.

Cài Đặt Thư Viện
Sử dụng lệnh sau để thiết lập các gói thư viện Python cần thiết:

Bash

pip install openai azure-openai python-dotenv langchain langchain-openai langchain-community langchain-tavily langgraph pyowm
# Thiết Lập Môi Trường
1. Sao chép và Cấu hình
Sao chép mã nguồn hoặc tập tin dự án về máy cục bộ của bạn.

Tạo tệp cấu hình: Sao chép tệp mẫu copy .env.example .env hoặc cp .env.example .env trong Linux/macOS.

Điền thông tin vào tệp .env: Cập nhật tệp .env với các khóa API và điểm cuối (endpoint) đã được cấp.

2. Chuẩn bị Dữ liệu Truy vấn
Tạo và chỉnh sửa tệp questions.txt. Mỗi câu hỏi (truy vấn) cần được viết trên một dòng riêng biệt.

Ví dụ về questions.txt:
Thời tiết ở Hà Nội hôm nay thế nào?
Tin tức mới nhất về phát triển AI là gì.
exit
Lưu ý: Tác nhân sẽ tự động dừng quá trình khi đọc thấy từ khóa exit.

# Hướng Dẫn Vận Hành
Mở giao diện dòng lệnh (Terminal/Command Prompt) và điều hướng đến thư mục chứa dự án.

Thực thi tập lệnh trợ lý bằng lệnh Python sau:

Bash

python ai-agent-wheather.py
Chương trình sẽ lần lượt đọc, xử lý và in ra câu trả lời cho từng truy vấn có trong tệp questions.txt.

# Lưu Ý Quan Trọng
Đảm bảo rằng tất cả Khóa API (Azure OpenAI, OpenWeatherMap, Tavily) đều có hiệu lực.

Cần có kết nối internet ổn định để thực hiện các cuộc gọi API.

Nếu bạn muốn sử dụng trợ lý theo thời gian thực (nhập liệu trực tiếp), hãy điều chỉnh logic đọc dữ liệu trong tập lệnh chính.