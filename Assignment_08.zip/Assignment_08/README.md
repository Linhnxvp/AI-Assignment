### How embeddings were created and used
The script uses Azure OpenAI `text-embedding-3-small` to convert product descriptions and user query into embedding vectors. Each embedding is a list of floating-point numbers representing semantic meaning.

### How to run
1. Install dependencies
    ```pip install scipy```
2. Create openai key for model text-embedding-3-small
3. Run:
   ```bash
   python main.py
   ```

### Cosine similarity for ranking
Cosine similarity is used to measure how close two vectors are. The similarity is computed as:

    sim(A, B) = dot(A, B) / (||A|| * ||B||)

Higher cosine similarity means the product is more relevant to the query. After calculating similarity for each product, the list is sorted in descending order to produce a ranked result.

### Challenges and limitations
- Embeddings depend on model quality — small models may produce less accurate ranking.
- Similarity only uses text meaning; price or category are not considered.
- Cold start: A new product with poor description may match badly.