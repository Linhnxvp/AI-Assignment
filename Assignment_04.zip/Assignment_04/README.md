# Overview



## How to Run

1. Install dependencies:
   ```bash
   pip install openai
   pip install tenacity
   ```

2. Run:
   ```bash
   python main.py
   ```


## Files
- `main.py` — single-file implementation with clear comments.
- `transcripts/` — 5 sample transcripts.
