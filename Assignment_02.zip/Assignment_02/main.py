import os
from openai import AzureOpenAI
import pandas as pd

# Step 1: Define mock task descriptions
task_descriptions = [
    "Install the battery module in the rear compartment, connect to the highvoltage harness, and verify torque on fasteners.",
    "Calibrate the ADAS (Advanced Driver Assistance Systems) radar sensors on the front bumper using factory alignment targets.",
    "Apply anti-corrosion sealant to all exposed welds on the door panels before painting.",
    "Perform leak test on coolant system after radiator installation. Record pressure readings and verify against specifications.",
    "Program the infotainment ECU with the latest software package and validate connectivity with dashboard display."
]

# environment variables
os.environ["AZURE_OPENAI_ENDPOINT"] = "https://aiportalapi.stu-platform.live/jpe"
os.environ["AZURE_OPENAI_API_KEY"] = "sk-3t7jDZ4d9Z6mTEB3YUyLlQ"
os.environ["AZURE_DEPLOYMENT_NAME"]= "GPT-4o-mini"

# Step 2: Setup Azure OpenAI client
client = AzureOpenAI(
    api_version="2024-07-01-preview",
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
)
deployment_name = "gpt-4o-mini"  # Replace with your actual deployment name

# Step 3: Function to generate work instructions
def generate_instruction(task):
    prompt = f"""
You are an expert automotive manufacturing supervisor. Generate step-by-step
work instructions for the following new model task. Include:

- Safety precautions
- Required tools
- Numbered steps
- Acceptance checks

Write clearly and concisely for production line workers.

Task:
\"\"\"{task}\"\"\"

Work Instructions:
"""
    try:
        response = client.chat.completions.create(
            model=deployment_name,
            messages=[{"role": "user", "content": prompt}],
            temperature=0,
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"Error generating instructions: {str(e)}"

# Step 4: Generate instructions and store results
results = []
for task in task_descriptions:
    instructions = generate_instruction(task)
    results.append({"Task Description": task, "Work Instructions": instructions})
    print(f"\nTask: {task}\nWork Instructions:\n{instructions}\n")

# Step 5: Save results to a CSV file
df = pd.DataFrame(results)
df.to_csv("work_instructions.csv", index=False)