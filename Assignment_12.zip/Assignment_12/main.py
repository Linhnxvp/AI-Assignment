# assignment12_satellite_cloud_detection.py
# pip install langchain-openai pillow requests pydantic

import os
import base64
import requests
from langchain_openai import AzureChatOpenAI
from pydantic import BaseModel, Field
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Setup Azure OpenAI LLM
llm = AzureChatOpenAI(
    azure_endpoint=os.environ["AZURE_OPENAI_LLM_ENDPOINT"],
    azure_deployment=os.environ["AZURE_OPENAI_LLM_MODEL"],
    api_key=os.environ["AZURE_OPENAI_LLM_API_KEY"],
    api_version="2024-02-15-preview",
)

# Define Output Schema
class WeatherResponse(BaseModel):
    accuracy: float = Field(description="The accuracy of the result")
    result: str = Field(description="The result of the classification: Clear or Cloudy")

llm_with_structured_output = llm.with_structured_output(WeatherResponse)

# Function Load Images
def load_image_urls(filepath="image_urls.txt"):
    with open(filepath, "r") as f:
        return [line.strip() for line in f if line.strip()]

# Function: classify image
def classify_satellite_image(image_url: str):
    print(f"\n--- Processing Image: {image_url} ---")

    try:
        response = requests.get(image_url)
        image_bytes = response.content
        image_base64 = base64.b64encode(image_bytes).decode("utf-8")

        # Prompt construction
        message = [
            {
                "role": "system",
                "content": """You are a satellite image analyst.
                Based on the given image, classify it as either:
                'Clear' (no clouds) or 'Cloudy' (with clouds).
                Respond only with 'Clear' or 'Cloudy' and an accuracy percentage.""",
            },
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Classify this satellite image."},
                    {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{image_base64}"}},
                ],
            },
        ]

        # Call Azure OpenAI
        result = llm_with_structured_output.invoke(message)
        print(f"Prediction: {result.result}")
        print(f"Accuracy : {result.accuracy:.2f} %")

    except Exception as e:
        print(f"Error processing image {image_url}: {e}")

# Main: Run classification
if __name__ == "__main__":
    image_urls = load_image_urls()
    print("Starting Cloud Detection...\n")
    for url in image_urls:
        classify_satellite_image(url)
        
print("Cloud detection process completed successfully.")
