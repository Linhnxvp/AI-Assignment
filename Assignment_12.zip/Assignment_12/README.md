# Satellite Cloud Detection

This project uses Azure OpenAI and satellite images to classify weather conditions as **Clear** or **Cloudy**.

## Prerequisites

- Python 3.8+ 
- [pip](https://pip.pypa.io/en/stable/installation/)
- Azure OpenAI credentials

## Installation

1. **Clone the repository**  
   Download or clone this folder to your local machine.

2. **Install dependencies**  
   ```
   pip install langchain-openai pillow requests pydantic python-dotenv
   ```

3. **Configure environment variables**  
   - Copy `.env.example` to `.env`:
     ```
     copy .env.example .env
     ```
   - Edit `.env` and fill in your Azure OpenAI credentials.

4. **Add image URLs**  
   - Create or edit `image_urls.txt` in the project folder.
   - Add one image URL per line.

## Running the Program

Run the following command in your terminal:
```
python satellite_cloud_detection.py
```

The program will:
- Load image URLs from `image_urls.txt`
- Download each image
- Send it to Azure OpenAI for classification
- Print the result and accuracy for each image

## Troubleshooting

- **API Key or Endpoint errors:**  
  Double-check your `.env` file for correct Azure OpenAI credentials.
- **Missing dependencies:**  
  Re-run the pip install command.
- **Image download errors:**  
  Make sure the URLs in `image_urls.txt` are valid and accessible.

## Example Output

```
--- Processing Image: https://images.pexels.com/photos/53594/blue-clouds-day-fluffy-53594.jpeg ---
Prediction: Cloudy
Accuracy : 97.50 %
```