# Overview

AI-Powered Meeting Summarizer Using **Azure OpenAI API**

## How to Run

1. Install dependencies:
   ```bash
   pip install openai
   ```

3. Run:
   ```bash
   python main.py
   ```

The script uses a **dummy input list** of sample transcripts located in `transcripts/`

Summaries will be printed to the console.

## Files
- `main.py` — single-file implementation with clear comments.
- `transcripts/` — 5 sample transcripts.
