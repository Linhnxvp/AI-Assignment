from openai import AzureOpenAI
import os

# environment variables
os.environ["AZURE_OPENAI_ENDPOINT"] = "https://aiportalapi.stu-platform.live/jpe"
os.environ["AZURE_OPENAI_API_KEY"] = "sk-3t7jDZ4d9Z6mTEB3YUyLlQ"
os.environ["AZURE_DEPLOYMENT_NAME"]= "GPT-4o-mini"

client = AzureOpenAI(
    api_version="2024-07-01-preview",
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
)

def summarize_transcript(transcript):
    prompt = f"Summarize the following meeting transcript with key points, decisions, and action items:\n\n{transcript}"

    response = client.chat.completions.create(
        model=os.getenv("AZURE_DEPLOYMENT_NAME"),
        messages=[
            {"role": "system", "content": "You are a helpful assistant specialized in summarizing meeting notes."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.3,
        max_tokens=500
    )

    summary = response.choices[0].message.content.strip()
    return summary

input_folder = "transcripts"

# Dummy run on all sample transcripts
for filename in os.listdir(input_folder):
    with open(os.path.join(input_folder, filename), "r", encoding="utf-8") as f:
        transcript = f.read()
        summary = summarize_transcript(transcript)
        print("Meeting Summary:\n")
        print(summary)
