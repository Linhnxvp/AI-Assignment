# How to install Llama (no need cmake, ninja, build tools)
    1. python -m pip install --upgrade pip setuptools wheel
    2. pip uninstall llama-cpp-python
    3. pip install llama-cpp-python --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cpu --prefer-binary

