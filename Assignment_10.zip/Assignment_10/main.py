import os
from pinecone import Pinecone, ServerlessSpec
from openai import AzureOpenAI
import json
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize client for Azure OpenAI
client = AzureOpenAI(
    api_version="2024-07-01-preview",
    azure_endpoint=os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_EMBEDDING_API_KEY"),
)

# Initialize for Pinecone
pc = Pinecone(api_key=os.getenv("PINECONE_API_KEY"))

# Create or Connect to Pinecone Index
index_name = "product-similarity-index"

if index_name not in [idx["name"] for idx in pc.list_indexes()]:
    pc.create_index(
        name=index_name,
        dimension=1536,  # dimension của model text-embedding-3-small
        spec=ServerlessSpec(cloud="aws", region="us-east-1"),
    )

index = pc.Index(index_name)

# Define Sample Product Dataset
with open("products.json", "r", encoding="utf-8") as f:
    products = json.load(f)

# Function to Generate Embeddings
def get_embedding(text: str):
    response = client.embeddings.create(
        input=text, model=os.getenv("AZURE_OPENAI_EMBED_MODEL")
    )
    return response.data[0].embedding

def get_batch_embeddings(texts):
    response = client.embeddings.create(
        input=texts, model=os.getenv("AZURE_OPENAI_EMBED_MODEL")
    )
    return [item.embedding for item in response.data]

def retrieve_similar_products(query, top_k=3):
    query_embedding = get_embedding(query)
    results = index.query(vector=query_embedding, top_k=top_k, include_metadata=True)
    return results

def load_user_queries(txt_path):
    with open(txt_path, "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]

def print_results(query, results):
    print(f"\nTop {len(results.matches)} similar products for the query: '{query}'\n")
    for match in results.matches:
        product_id = match.id
        score = match.score
        metadata = match.metadata
        print(f"- {metadata['title']} (Similarity score: {score:.4f})")

vectors = []
BATCH_SIZE = 10
for i in range(0, len(products), BATCH_SIZE):
    batch = products[i:i+BATCH_SIZE]
    texts = [p["title"] + " " + p["description"] for p in batch]
    embeddings = get_batch_embeddings(texts)
    for p, emb in zip(batch, embeddings):
        vectors.append((p["id"], emb, {"title": p["title"], "description": p["description"]}))

# Upsert into Pinecone
index.upsert(vectors)

# Query Similar Products
queries = load_user_queries("inputs.txt")
top_k = 3

for query in queries:
    query_embedding = get_embedding(query)
    results = index.query(vector=query_embedding, top_k=top_k, include_metadata=True)

    # Display Results
    print_results(query, results)

