# Tìm kiếm Sản phẩm Tương đồng: Ứng dụng Pinecone và Azure OpenAI
Tóm tắt Dự án
Dự án này là một hệ thống tìm kiếm độ tương đồng sản phẩm, tận dụng sức mạnh của các vector nhúng (vector embeddings) được tạo bởi Azure OpenAI và được lưu trữ/truy vấn từ cơ sở dữ liệu vector Pinecone. Chương trình sẽ đọc dữ liệu sản phẩm từ tệp products.json và các câu truy vấn từ inputs.txt. Sau khi xử lý, nó sẽ xuất ra danh sách các sản phẩm có độ tương đồng cao nhất cho mỗi truy vấn, cùng với điểm số tương đồng tương ứng.

# Yêu cầu Hệ thống
Để triển khai dự án, bạn cần chuẩn bị:

Phiên bản Python 3.8 trở lên.

Trình quản lý gói pip.

Tài khoản Azure OpenAI, bao gồm khóa API và điểm cuối (endpoint) cho dịch vụ tạo vector nhúng.

Tài khoản Pinecone, bao gồm khóa API và cấu hình chỉ mục (index) cần thiết.

# Cài đặt và Thiết lập
1. Cài đặt các Thư viện
Sử dụng lệnh sau để cài đặt các gói Python cần thiết:

Bash

pip install openai azure-openai python-dotenv pinecone
2. Cấu hình Biến Môi trường
Tạo một tệp có tên là .env ngay trong thư mục dự án và điền các thông tin xác thực của bạn vào:

AZURE_OPENAI_EMBEDDING_ENDPOINT=điểm_cuối_azure_openai_của_bạn
AZURE_OPENAI_EMBEDDING_API_KEY=khóa_api_azure_openai_của_bạn
AZURE_OPENAI_EMBED_MODEL=tên_mô_hình_embedding_của_bạn
PINECONE_API_KEY=khóa_api_pinecone_của_bạn
3. Chuẩn bị Dữ liệu Sản phẩm
Cập nhật tệp products.json với bộ dữ liệu sản phẩm mà bạn muốn sử dụng.

4. Thiết lập Truy vấn Tìm kiếm
Chỉnh sửa tệp inputs.txt và thêm vào các câu truy vấn tìm kiếm của bạn, mỗi câu trên một dòng riêng biệt.

# Thực thi Chương trình
Chạy tập lệnh chính từ terminal của bạn:

Bash

python pinecone-retrieve-similar-product.py
# Kết quả Đầu ra
Chương trình sẽ hiển thị các sản phẩm hàng đầu được xác định là tương đồng nhất với mỗi truy vấn trong tệp inputs.txt, liệt kê tên sản phẩm và điểm số tương đồng tương ứng.

# Khắc phục Sự cố
Xác minh lại các khóa API và địa chỉ điểm cuối (endpoint) đã được nhập chính xác trong tệp .env.

Đảm bảo rằng các tệp products.json và inputs.txt nằm cùng thư mục với tập lệnh chính.

Kiểm tra kết nối internet để đảm bảo các lệnh gọi API được thực hiện thành công.

# Danh sách Tệp
pinecone-retrieve-similar-product.py — Tập lệnh thực thi chính.

products.json — Tệp chứa dữ liệu sản phẩm.

inputs.txt — Tệp chứa các câu truy vấn đầu vào.

.env — Tệp cấu hình các biến môi trường.