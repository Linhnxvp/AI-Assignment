# 🩺 Medical Assistant Agent (LangGraph RAG/Tool-Use Example)

This project demonstrates a simple medical assistant agent built using **LangGraph** to orchestrate tool use, specifically combining **Retrieval-Augmented Generation (RAG)** over local documents with a **web search** tool for external information.

## ⚙️ Architecture Overview

The agent operates as a state machine with the following nodes and edges:

1.  **Start** $\rightarrow$ **Call Model**
2.  **Call Model** $\rightarrow$ **Conditional Edge** ($\rightarrow$ **Tools** or $\rightarrow$ **End**)
3.  **Tools** $\rightarrow$ **Call Model**

### Nodes

* **`call_model`**: The central reasoning step. The LLM decides whether the user's query requires a tool call (either RAG or web search) or if it can answer directly based on the conversation history.
* **`tools`**: Executes any tools requested by the LLM in the previous step.

### Tools

The agent has access to two tools:

1.  **`retrieve_advice` (Internal RAG)**: Searches a small, mocked internal **FAISS** vector store of medical advice documents. This is used for standard, known patient guidance.
2.  **`tavily_search` (Web Search)**: An external tool for gathering up-to-date or general knowledge not contained in the internal documents.

## 🚀 Setup and Installation

### Prerequisites

You need to set up API keys for **Azure OpenAI** (for the LLM and Embeddings) and **Tavily Search** (for the web search tool).

1.  **API Keys:** Obtain keys for your Azure OpenAI services and a Tavily API key.
2.  **`.env` File:** Create a file named **`.env`** in the project root and populate it with your credentials:

    ```env
    # --- Tavily Search ---
    TAVILY_API_KEY="YOUR_TAVILY_API_KEY"

    # ---- EMBEDDING CONFIG ----
    AZURE_OPENAI_EMBEDDING_API_KEY="YOUR_AZURE_EMBEDDING_API_KEY"
    AZURE_OPENAI_EMBEDDING_ENDPOINT="YOUR_AZURE_EMBEDDING_ENDPOINT"
    AZURE_OPENAI_EMBED_MODEL="YOUR_AZURE_EMBEDDING_DEPLOYMENT_NAME"

    # ---- LLM CONFIG ----
    AZURE_OPENAI_LLM_API_KEY="YOUR_AZURE_LLM_API_KEY"
    AZURE_OPENAI_LLM_ENDPOINT="YOUR_AZURE_LLM_ENDPOINT"
    AZURE_OPENAI_LLM_MODEL="YOUR_AZURE_LLM_DEPLOYMENT_NAME"
    ```

### Python Dependencies

Install the required libraries using the provided command:

```bash
pip install langchain-openai langchain-community langgraph faiss-cpu langchain-core langchain-tavily python-dotenv