# !pip install langchain-openai langchain-community langchain_openai langgraph faiss-cpu langchain-core langchain-tavily python-dotenv

from langchain_core.documents import Document
from langgraph.graph import StateGraph, MessagesState, START, END
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from langchain_community.vectorstores.faiss import FAISS
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.tools import tool
from langgraph.prebuilt import ToolNode
from langchain_tavily import TavilySearch
import os
from dotenv import load_dotenv

# --- Load environment variables ---
load_dotenv()

# ---- EMBEDDING CONFIG ----
AZURE_OPENAI_EMBEDDING_API_KEY = os.getenv("AZURE_OPENAI_EMBEDDING_API_KEY")
AZURE_OPENAI_EMBEDDING_ENDPOINT = os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT")
AZURE_OPENAI_EMBED_MODEL = os.getenv("AZURE_OPENAI_EMBED_MODEL")

# ---- LLM CONFIG ----
AZURE_OPENAI_LLM_API_KEY = os.getenv("AZURE_OPENAI_LLM_API_KEY")
AZURE_OPENAI_LLM_ENDPOINT = os.getenv("AZURE_OPENAI_LLM_ENDPOINT")
AZURE_OPENAI_LLM_MODEL = os.getenv("AZURE_OPENAI_LLM_MODEL")

# --- Mock documents ---
mock_chunks = [
    Document(
        page_content="Patients with a sore throat should drink warm fluids and avoid cold beverages."
    ),
    Document(
        page_content="Mild fevers under 38.5°C can often be managed with rest and hydration."
    ),
    Document(
        page_content="If a patient reports dizziness, advise checking their blood pressure and hydration level."
    ),
    Document(
        page_content="Persistent coughs lasting more than 2 weeks should be evaluated for infections or allergies."
    ),
    Document(
        page_content="Patients experiencing fatigue should consider iron deficiency or poor sleep as potential causes."
    ),
]

# --- Setup LLM ---
llm = AzureChatOpenAI(
    azure_endpoint=AZURE_OPENAI_LLM_ENDPOINT,
    api_key=AZURE_OPENAI_LLM_API_KEY,
    azure_deployment=AZURE_OPENAI_LLM_MODEL,
    api_version="2024-02-15-preview",
)

# --- Setup Embedding & Vector Store ---
embedding_model = AzureOpenAIEmbeddings(
    model=AZURE_OPENAI_EMBED_MODEL,
    api_key=AZURE_OPENAI_EMBEDDING_API_KEY,
    azure_endpoint=AZURE_OPENAI_EMBEDDING_ENDPOINT,
    api_version="2024-02-15-preview",
)
db = FAISS.from_documents(mock_chunks, embedding_model)
retriever = db.as_retriever()


# --- TOOL 1: RETRIEVE ADVICE ---
@tool
def retrieve_advice(user_input: str) -> str:
    """Searches internal documents for relevant patient advice."""
    docs = retriever.invoke(user_input)
    return "\n".join(doc.page_content for doc in docs)


# --- TOOL 2: TAVILY SEARCH ---
tavily_tool = TavilySearch(max_results=1)

# --- Bind tools to LLM ---
llm_with_tools = llm.bind_tools([retrieve_advice, tavily_tool])


# --- MODEL NODE ---
def call_model(state: MessagesState):
    messages = state["messages"]
    response = llm_with_tools.invoke(messages)
    return {"messages": [response]}


# --- CONDITIONAL ROUTING ---
def should_continue(state: MessagesState):
    last_message = state["messages"][-1]
    if getattr(last_message, "tool_calls", None):
        return "tools"
    return END


# --- TOOL NODE ---
tool_node = ToolNode([retrieve_advice, tavily_tool])

# --- BUILD THE GRAPH ---
graph_builder = StateGraph(MessagesState)
graph_builder.add_node("call_model", call_model)
graph_builder.add_node("tools", tool_node)
graph_builder.add_edge(START, "call_model")
graph_builder.add_conditional_edges("call_model", should_continue, ["tools", END])
graph_builder.add_edge("tools", "call_model")
graph = graph_builder.compile()

# --- RUN ---
if __name__ == "__main__":
    result = graph.invoke(
        {
            "messages": [
                SystemMessage(
                    content="You are a helpful medical assistant. Use tools if needed."
                ),
                HumanMessage(
                    content="I feel tired and have a sore throat. What should I do?"
                ),
            ]
        }
    )
    print("Final Response:")
    print(result["messages"][-1].content)